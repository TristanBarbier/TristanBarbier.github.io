from csvReader2 import importCSV, exportCSV, filtrerColonne

def verifieCle(table1, table2):
    dico = {}
    nbEnTete1 = len(table1[0].keys())
    nbEnTete2 = len(table2[0].keys())
    if nbEnTete1 == nbEnTete2 :
        for cle1 in table1[0].keys():
            dico[cle1] = False
            for cle2 in table2[0].keys():
                if cle1 == cle2:
                    dico[cle1] = True
        if False in dico.values(): return False
        else: return True
    else :
        print("Les tables n'ont pas la meme table")
        return False

def verifieCle2(table1, table2):
    for cle1 in table1[0].keys():
        try:
            table2[0][cle1]
        except:
            return False
    return True
        
#def fusion(table11, table2) :
   # if VerifieCle(table1, table2) == True:
   # else :
        #print("Les tables ne sont pas fusionnables")
        #return None


def keyCheck(table1: list, table2: list) -> bool:
    if len(table1[0].keys()) == len(table2[0].keys()):
        for key1 in table1[0].keys():
            try: table2[0][key1]
            except KeyError:
                print('Les tableaux ne sont pas compatibles.')
                return False
        return True
    else: return True

def fusionTable(table1: list, table2: list, key: str) -> list:
    if keyCheck(table1, table2) == True: return table1+table2
    else: print('Ces tableaux ne sont pas fusionnables')

def mergeTable(table1: list, table2: list, key: str) -> list:
    finalTable = []
    for dico1 in table1:
        newDict = {}
        for dico2 in table2:
            if dico1[key] == dico2[key]:
                for (key1, value1) in dico1.items():
                    newDict[key1] = value1
                for (key2, value2) in dico2.items():
                    newDict[key2] = value2
                finalTable.append(newDict)
    return finalTable
