import folium
from csvReader2 import*
maTable = importCSV('finalTable.csv')

def folium_json(table: list, state: str):
    json = '{"title": "' + state + '", "data": {"values": ['
    for year in range(2007, 2018):
        for dico in table:
            if dico['State'] == state:
                json += '{"année": "' + str(year) + '", "revenu": '+ dico[str(year)] + '},'
    json = json[:-1] + ']}, "mark": "bar", "encoding": {"x": {"field": "année", "type": "nominal"}, "y": {"field": "revenu", "type": "quantitative"}}}'
    return json

def gps_marker(table: list, state: str):
    for dico in table:
        if dico['State'] == state:
            coords = [float(dico['Latitude']), float(dico['Longitude'])]
    return coords

map = folium.Map(location=[39.572,-97.383], zoom_start=4)
for line in maTable:
    folium.Marker(location= gps_marker(maTable, line["State"]), popup = folium.Popup().add_child(folium.VegaLite(folium_json(maTable, line["State"])))).add_to(map)
map.save('map.html')

