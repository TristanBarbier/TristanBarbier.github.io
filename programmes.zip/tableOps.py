import csv
from operator import itemgetter, attrgetter
from csvReader2 import*
from jointure import*

table = importCSV('householdMedianIncome.csv')
table2 = importCSV('stateLatLong.csv')

headers = [str(i) for i in range(2017, 2006, -1)]
headers.append('State')
table1 = filterColumn(table, headers)
exportCSV(table1, 'tableProduct.csv')
#use table1 since it is final product
commonHeader = str('State')
finalTable = mergeTable(table1, table2, commonHeader)
exportCSV(finalTable, 'finalTable.csv')                                                                                                      



